#include "Fraction.h"


//Konstruktor

Fraction::Fraction(int whole, int num, int denom) : wholePart(whole), numerator(num), denominator(denom) {}

//Konverzios operatorok: double es string

//Operator+ fuggveny

//Konverzios konstruktor


