#pragma once
#include <stdio.h>

class Computer
{
	unsigned nextId;
	unsigned id;
	unsigned clockSpeed;
public:
	Computer();
	Computer(Computer&); //Vigyazz! A masolatnak is egyedi azonositoja legyen!
	unsigned getClockSpeed();
	void print();
	void friendlyPrint(Computer&); //Ez ne legyen tagfuggveny!
};

void friendlyPrint(Computer&);