#include "Product.h"


    Product::Product(int pid, const std::string& pname, double pprice)
        : price((pprice > MAX_PRICE) ? MAX_PRICE : pprice)/*, ?? */  {
        //TODO
    }

    Product::~Product() {
        //TODO
    }

    //TODO maradek tagfv
