﻿#include "Malacpersely.h"

void Malacpersely::bedob(int penz) {
	penztartalom += penz;
}

void Malacpersely::atont(Malacpersely& masik) {
	penztartalom += masik.penztartalom;
	masik.penztartalom = 0;
}

