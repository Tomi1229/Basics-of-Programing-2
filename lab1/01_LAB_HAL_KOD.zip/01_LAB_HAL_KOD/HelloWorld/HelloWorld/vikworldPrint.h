#ifndef _VIKWORLD
#define _VIKWORLD
#include <stdio.h>

void vikworld();

#endif