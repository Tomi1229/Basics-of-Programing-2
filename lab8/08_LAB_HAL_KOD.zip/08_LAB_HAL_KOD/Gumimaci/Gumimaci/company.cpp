#include "company.h"
#include <iostream>

using namespace std;

