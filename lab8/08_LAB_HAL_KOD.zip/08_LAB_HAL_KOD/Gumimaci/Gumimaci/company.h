#pragma once
#include "partner.h"
#include <string>

class Company  {
	std::string businessName;

	// Value Added Tax Identifier Number
	// A nevében ugyan Number van, viszont tipikusan string szokott lenni.
	std::string VATIN;
public:
};

