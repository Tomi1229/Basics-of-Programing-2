#pragma once
#include "partner.h"

class Person {
};

